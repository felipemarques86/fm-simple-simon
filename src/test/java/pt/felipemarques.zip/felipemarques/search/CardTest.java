package pt.felipemarques.search;

import org.junit.jupiter.api.Test;
import pt.felipemarques.ss.model.Card;
import pt.felipemarques.ss.model.Deck;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CardTest {

    @Test
    public void test1(){
        List<Card> allCards = Card.getAllCards();
        List<Card> cards = allCards.stream().filter(c -> c.getKind().equals(Card.Kind.diamonds)).sorted().collect(Collectors.toList());

        for(int i = 0; i < cards.size()-1; i++) {
            assertTrue(cards.get(i+1).followedBy(cards.get(i)), cards.get(i).simpleDisplay() + " should be smaller than " + cards.get(i+1).simpleDisplay());
        }
    }

    @Test
    public void test2(){
        Deck deck = new Deck();
        Card c1 = deck.seek(Card.Kind.spades, '7');
        Card c2 = deck.seek(Card.Kind.spades, '5');
        assertFalse(c1.followedBy(c2));

        c1 = deck.seek(Card.Kind.spades, '8');
        c2 = deck.seek(Card.Kind.spades, '9');
        assertFalse(c1.followedBy(c2));

        c1 = deck.seek(Card.Kind.spades, '2');
        c2 = deck.seek(Card.Kind.spades, 'A');
        assertTrue(c1.followedBy(c2));

        c1 = deck.seek(Card.Kind.diamonds, '8');
        c2 = deck.seek(Card.Kind.diamonds, 'A');
        assertFalse(c1.followedBy(c2));
    }

}
