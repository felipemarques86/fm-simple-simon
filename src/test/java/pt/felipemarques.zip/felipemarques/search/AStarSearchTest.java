package pt.felipemarques.search;

import org.junit.jupiter.api.Test;
import pt.felipemarques.ss.model.Card;
import pt.felipemarques.ss.model.Deck;
import pt.felipemarques.ss.model.Solitaire;
import pt.felipemarques.ss.model.SolitaireColumn;
import pt.felipemarques.ss.search.AStarSearch;
import pt.felipemarques.ss.search.Search;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AStarSearchTest {

    public static  Solitaire getInitialSolitaire(Deck deck) {
        Solitaire solitaire = new Solitaire();
        SolitaireColumn col1 = solitaire.createColumn();
        col1.add(deck.seek(Card.Kind.hearts, '0'));
        col1.add(deck.seek(Card.Kind.spades, '4'));
        col1.add(deck.seek(Card.Kind.hearts, '2'));
        col1.add(deck.seek(Card.Kind.hearts, '8'));
        col1.add(deck.seek(Card.Kind.diamonds, '8'));
        col1.add(deck.seek(Card.Kind.clubs, '0'));
        SolitaireColumn col2 = solitaire.createColumn();
        col2.add(deck.seek(Card.Kind.diamonds, 'V'));
        col2.add(deck.seek(Card.Kind.diamonds, '3'));
        col2.add(deck.seek(Card.Kind.diamonds, '7'));
        SolitaireColumn col3 = solitaire.createColumn();
        col3.add(deck.seek(Card.Kind.spades, '9'));
        col3.add(deck.seek(Card.Kind.spades, 'A'));
        col3.add(deck.seek(Card.Kind.diamonds, 'A'));
        col3.add(deck.seek(Card.Kind.spades, '5'));
        col3.add(deck.seek(Card.Kind.hearts, '4'));
        col3.add(deck.seek(Card.Kind.diamonds, 'D'));
        col3.add(deck.seek(Card.Kind.hearts, 'R'));
        SolitaireColumn col4 = solitaire.createColumn();
        col4.add(deck.seek(Card.Kind.clubs, '4'));
        col4.add(deck.seek(Card.Kind.clubs, 'V'));
        col4.add(deck.seek(Card.Kind.hearts, '5'));
        col4.add(deck.seek(Card.Kind.hearts, '9'));
        col4.add(deck.seek(Card.Kind.clubs, '8'));
        col4.add(deck.seek(Card.Kind.hearts, 'V'));
        SolitaireColumn col5 = solitaire.createColumn();
        col5.add(deck.seek(Card.Kind.spades, '6'));
        col5.add(deck.seek(Card.Kind.spades, '3'));
        col5.add(deck.seek(Card.Kind.hearts, 'A'));
        col5.add(deck.seek(Card.Kind.diamonds, '4'));
        col5.add(deck.seek(Card.Kind.spades, '8'));
        col5.add(deck.seek(Card.Kind.spades, '0'));
        col5.add(deck.seek(Card.Kind.diamonds, '0'));
        SolitaireColumn col6 = solitaire.createColumn();
        col6.add(deck.seek(Card.Kind.diamonds, '2'));
        col6.add(deck.seek(Card.Kind.hearts, '6'));
        col6.add(deck.seek(Card.Kind.clubs, 'A'));
        col6.add(deck.seek(Card.Kind.spades, '2'));
        col6.add(deck.seek(Card.Kind.hearts, '3'));
        col6.add(deck.seek(Card.Kind.diamonds, '6'));
        SolitaireColumn col7 = solitaire.createColumn();
        col7.add(deck.seek(Card.Kind.clubs, 'D'));
        col7.add(deck.seek(Card.Kind.spades, '7'));
        col7.add(deck.seek(Card.Kind.hearts, 'D'));
        col7.add(deck.seek(Card.Kind.clubs, '2'));
        col7.add(deck.seek(Card.Kind.hearts, '7'));
        col7.add(deck.seek(Card.Kind.diamonds, 'R'));
        col7.add(deck.seek(Card.Kind.clubs, 'R'));
        col7.add(deck.seek(Card.Kind.spades, 'D'));
        SolitaireColumn col8 = solitaire.createColumn();
        col8.add(deck.seek(Card.Kind.clubs, '5'));
        col8.add(deck.seek(Card.Kind.diamonds, '5'));
        SolitaireColumn col9 = solitaire.createColumn();
        col9.add(deck.seek(Card.Kind.clubs, '3'));
        col9.add(deck.seek(Card.Kind.clubs, '9'));
        col9.add(deck.seek(Card.Kind.spades, 'R'));
        col9.add(deck.seek(Card.Kind.clubs, '6'));
        SolitaireColumn col10 = solitaire.createColumn();
        col10.add(deck.seek(Card.Kind.clubs, '7'));
        col10.add(deck.seek(Card.Kind.diamonds, '9'));
        col10.add(deck.seek(Card.Kind.spades, 'V'));

        assertTrue(deck.size() == 0);

        return solitaire;
    }


    @Test
    public void test() {
        Deck deck = new Deck();
        Search search = new AStarSearch();
        try {
            Solitaire initialSolution = getInitialSolitaire(deck);
            Solitaire solution = search.search(initialSolution, deck);
            System.out.println("Expansões: " + search.getExpansions());
            System.out.println("Iterações: " + search.getIterations());
            System.out.println("Cost of final solution: " + solution.getCost());
            System.out.println(solution.display());
            assertNotNull(solution);
        } catch(Exception ex) {
            System.out.println("Expansões: " + search.getExpansions());
            System.out.println("Iterações: " + search.getIterations());
            ex.printStackTrace();
        }
    }
}
