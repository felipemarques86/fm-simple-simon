package pt.felipemarques.search;

import org.junit.jupiter.api.Test;
import pt.felipemarques.ss.model.Card;
import pt.felipemarques.ss.model.Deck;
import pt.felipemarques.ss.model.Solitaire;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class SolitaireTest {

    @Test
    public void test1() {
        Solitaire solitaire = new Solitaire();
        Deck deck = new Deck();
        solitaire.createColumns(9);

        solitaire.column(0).addCard(Card.Kind.diamonds, 'A', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '9', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '8', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '7', deck);
        System.out.println(solitaire.simpleDisplay());

        assertTrue(solitaire.move(0, 2, 1));

        System.out.println(solitaire.simpleDisplay());
    }


    @Test
    public void test2() {
        Solitaire solitaire = new Solitaire();
        Deck deck = new Deck();
        solitaire.createColumns(9);

        solitaire.column(0).addCard(Card.Kind.spades, '6', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '5', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '4', deck);

        solitaire.column(1).addCard(Card.Kind.spades, '9', deck);
        solitaire.column(1).addCard(Card.Kind.spades, '8', deck);
        solitaire.column(1).addCard(Card.Kind.spades, '7', deck);



        assertTrue(solitaire.move(0, 1, 3));

        System.out.println(solitaire.simpleDisplay());
    }

    @Test
    public void test2_1() {
        Solitaire solitaire = new Solitaire();
        Deck deck = new Deck();
        solitaire.createColumns(9);

        solitaire.column(0).addCard(Card.Kind.spades, '6', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '5', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '4', deck);

        solitaire.column(1).addCard(Card.Kind.spades, '9', deck);
        solitaire.column(1).addCard(Card.Kind.spades, '8', deck);
        solitaire.column(1).addCard(Card.Kind.spades, '7', deck);

        List<Solitaire.Movement> movements = solitaire.successorsMovements(deck);
        for(Solitaire.Movement mov : movements)
            System.out.println(mov.toString());

        System.out.println(solitaire.simpleDisplay());
    }

    @Test
    public void test3() {
        Solitaire solitaire = new Solitaire();
        Deck deck = new Deck();
        solitaire.createColumns(9);

        solitaire.column(0).addCard(Card.Kind.spades, '6', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '5', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '4', deck);

        solitaire.column(1).addCard(Card.Kind.spades, '7', deck);
        solitaire.column(1).addCard(Card.Kind.spades, '8', deck);
        solitaire.column(1).addCard(Card.Kind.spades, '9', deck);

        System.out.println(solitaire.simpleDisplay());

        assertTrue(!solitaire.move(0, 1, 3));

        System.out.println(solitaire.simpleDisplay());
    }

    @Test
    public void test4() {
        Solitaire solitaire = new Solitaire();
        Deck deck = new Deck();
        solitaire.createColumns(10);


        solitaire.column(0).addCard(Card.Kind.spades, '9', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '8', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '7', deck);

        Set<Solitaire> successors = solitaire.successors(deck);

        System.out.println(successors.size());

        for(Solitaire s : successors) {
            System.out.println(s.simpleDisplay());
        }
    }

    @Test
    public void test5() {
        Solitaire solitaire = new Solitaire();
        Deck deck = new Deck();
        solitaire.createColumns(9);

        solitaire.column(0).addCard(Card.Kind.diamonds, 'A', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '9', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '8', deck);
        solitaire.column(0).addCard(Card.Kind.spades, '7', deck);
        //solitaire.column(0).addCard(Card.Kind.spades, '5', deck);
        System.out.println(solitaire.simpleDisplay());

        assertTrue(solitaire.move(0, 1, 2));

        System.out.println(solitaire.simpleDisplay());
    }

    @Test
    public void test6() {
        Deck deck = new Deck();
        Solitaire initialSolitaire = AStarSearchTest.getInitialSolitaire(deck);

        System.out.println(initialSolitaire.simpleDisplay());

        System.out.println();

        for (Solitaire successor : initialSolitaire.successors(deck)) {
            System.out.println("Movement: " + successor.getMovement());
            System.out.println(successor.simpleDisplay());
        }

    }

    @Test
    public void test7() {
        Deck deck = new Deck();
        Solitaire initialSolitaire = AStarSearchTest.getInitialSolitaire(deck);

        System.out.println(initialSolitaire.simpleDisplay());

        System.out.println();
        List<Solitaire.Movement> movements = initialSolitaire.successorsMovements(deck);
        movements.get(0).toString().equals("10P;4");
        movements.get(1).toString().equals("10P;10");
        movements.get(2).toString().equals("VC;7");
        movements.get(3).toString().equals("10O;4");
        movements.get(4).toString().equals("10O;10");
        movements.get(5).toString().equals("6O;2");
        movements.get(6).toString().equals("DE;3");
        movements.get(7).toString().equals("5O;6");
        movements.get(8).toString().equals("5O;9");
        movements.get(9).toString().equals("6P;2");
        movements.get(10).toString().equals("VE;7");

        for(Solitaire.Movement movement : movements) {
            System.out.println(movement.toString());
        }
    }

    @Test
    public void test8() {
        Deck deck = new Deck();
        Solitaire initialSolitaire = AStarSearchTest.getInitialSolitaire(deck);

        System.out.println(initialSolitaire.simpleDisplay());

        System.out.println();
        List<Solitaire.Movement> movements = initialSolitaire.successorsMovements(deck);
        //movements.get(0).toString().equals("10P;4");

        Solitaire solitaire2 = initialSolitaire.clone();

        solitaire2.move(movements.get(0));

        System.out.println(solitaire2.simpleDisplay());
    }

    @Test
    public void test9() {
        Solitaire solitaire = new Solitaire();
        Deck deck = new Deck();
        solitaire.createColumns(10);

        solitaire.column(8).addCard(Card.Kind.clubs, '3', deck);
        solitaire.column(8).addCard(Card.Kind.clubs, '9', deck);
        solitaire.column(8).addCard(Card.Kind.clubs, 'R', deck);
        solitaire.column(8).addCard(Card.Kind.clubs, '6', deck);

        List<Solitaire.Movement> movements = solitaire.successorsMovements(deck);
        System.out.println();
        solitaire.move(movements.get(0));
        movements = solitaire.successorsMovements(deck);
        System.out.println();
        solitaire.move(movements.get(0));
        System.out.println();
        movements = solitaire.successorsMovements(deck);
        solitaire.move(movements.get(0));
        System.out.println();
        movements = solitaire.successorsMovements(deck);
        System.out.println("MOVEMENT: ");
        System.out.println(movements.get(16).toString());
        solitaire.move(movements.get(16));
        System.out.println(solitaire.display());
    }

}
