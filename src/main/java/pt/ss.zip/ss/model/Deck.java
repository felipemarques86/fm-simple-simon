package pt.felipemarques.ss.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Deck {
    private Stack<Card> cards;
    private List<Card> used = new ArrayList<>();

    public Deck() {
        this.cards = new Stack<>();
        Card.getAllCards().stream().forEach(this.cards::push);
    }

    public void shuffle() {
        if(cards != null) {
            Collections.shuffle(this.cards);
        }
    }

    public Card draw() {
        if(cards.empty())
            return null;
        return cards.pop();
    }

    public Card seek(Card c) {
        Card card = cards.stream().filter(c1 -> c1.equals(c)).findFirst().get();
        cards.remove(card);
        return card;
    }

    public Card seek(Card.Kind kind, char value) {
        Card c = cards.stream().filter( card -> card.getKind() == kind && card.getValue() == value).findFirst().orElse(null);
        if(c!= null) {
            cards.remove(c);
            used.add(c);
        }
        return c;
    }

    public String display() {
        StringBuilder sb = new StringBuilder();
        if(cards != null) {
            this.cards.stream().forEach(sb::append);
        }
        return sb.toString();
    }

    public int size() {
        return cards.size();
    }

    public void forEachUsedCard(Consumer<Card> consumer) {
        this.used.stream().forEach(consumer);
    }

    public Stream<Card> filterCards(Predicate<Card> predicate) {
        return this.cards.stream().filter(predicate);
    }

    public List<Card> getUsed() {
        return used;
    }
}
