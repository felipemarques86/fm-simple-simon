package pt.felipemarques.ss.model;

import java.util.*;

public class SolitaireColumn extends CardRange {

    private int col;
    public static final char [] values = {'A', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'V', 'D', 'R'};

    public boolean allSameKind() {
        return cards.stream().allMatch( cards -> cards.getKind() == Card.Kind.clubs) ||
               cards.stream().allMatch( cards -> cards.getKind() == Card.Kind.hearts) ||
               cards.stream().allMatch( cards -> cards.getKind() == Card.Kind.diamonds) ||
               cards.stream().allMatch( cards -> cards.getKind() == Card.Kind.spades);
    }

    public boolean isSolved() {
        if(cards.size() != values.length)
            return false;
        for(int i = 0; i < cards.size(); i++) {
            if(cards.get(i).getValue() != values[i])
                return false;
        }
        return allSameKind();
    }


    public SolitaireColumn(int col) {
        this.col = col;
    }

    public boolean add(Card.Kind kind, char value) {
        return cards.add(Card.getCard(kind, value));
    }

    public void add(Card card) {
        if(card == null)
            throw new RuntimeException("Trying to add null card");
        card.setCurrentColumn(this);
        cards.push(card);
    }

    @Override
    protected SolitaireColumn clone() {
        final SolitaireColumn newCol = new SolitaireColumn(this.col);
        List<Card> newCards = new ArrayList<>();
        Deck deck = new Deck();
        this.cards.stream().forEach( c -> {
            Card newCard = deck.seek(c);
            newCards.add(newCard);
            newCard.setCurrentColumn(newCol);
        });
        newCol.cards.addAll(newCards);
        return newCol;
    }

    public void distribute(Deck deck, int n) {
        for(int i = 0; i < Math.min(deck.size(), n); i++) {
            cards.push(deck.draw());
        }
    }

    public String display() {
        StringBuilder sb = new StringBuilder();
        sb.append("┌─── ");
        sb.append(col);
        sb.append(" ");
        if(col < 10)
            sb.append("─");
        sb.append("───┐");
        sb.append("\r\n");
        sb.append("│          │");
        sb.append("\r\n");

        int sd = simpleDistance();
        int distance = distance();
        int sequenceDistance = sequenceDistance();
        int kindConsistency = kindConsistency();
        String solved = isSolved() ? "Y" : "N";
        String order = isInOrder() ? "Y" : "N";

/*        sb.append("   sid: " + (sd < 10 ? "0" : "") + sd );sb.append("  \r\n");

        sb.append("   dist:" + (distance < 10 ? "0" : "") + distance );sb.append("  \r\n");

        sb.append("   seqd:" + (sequenceDistance < 10 ? "0" : "") + sequenceDistance );sb.append("  \r\n");

        sb.append("   kc:  " + (kindConsistency < 10 ? "0" : "") + kindConsistency );sb.append("  \r\n");

        sb.append("   sol? " + solved);sb.append("   \r\n");

        sb.append("   ord? " + order);sb.append("   \r\n");*/

        if(cards != null) {
            this.cards.stream().forEach( card -> {
                sb.append(card.display(3));
            });
        }
        return sb.toString();
    }



    public void distribute(Deck deck) {
        if(deck.size() == 0)
            return;
        Random r  = new Random();
        int i =   deck.size() == 1 ? 1 : r.nextInt(1, deck.size());
        distribute(deck, i);
    }

    public synchronized Card popIfAvailable(Card.Kind kind, char value) {
        if(cards.empty()) {
            return null;
        }
        Card peek = cards.peek();
        if(peek != null && peek.getKind() == kind && peek.getValue() == value) {
            return cards.pop();
        }
        return null;
    }

    /*public boolean pushIfPossible(Card c) {
        if(cards.empty()) {
            cards.push(c);
            return true;
        }
        final Card peek = cards.peek();
        if( peek.greatherThan(c) ) {
            cards.push(c);
            return true;
        }
        return false;
    }*/



    public Card pop() {
        return cards.pop();
    }

    // Heurísticas
    public int simpleDistance() {
        return 52 - cards.size();
    }

    public int distance() {
        int k = 0;
        for(int i = 0; i < cards.size(); i++) {
            if(i > values.length-1) {
                k+=5;
            } else if(cards.get(i).getValue() == values[i]) {
                k++;
            }
        }
        return 52*5 - k;
    }


    public int sequenceDistance() {
        int k = 0;
        for(int i = 1; i < cards.size(); i++) {
            if(cards.get(i).followedBy(cards.get(i-1))) {
                k++;
            }
        }
        return 52 - k;
    }

    public int kindConsistency() {
        int k = 0;
        for(int i = 1; i < cards.size(); i++) {
            if(cards.get(i).getKind() == cards.get(i-1).getKind()) {
                k++;
            }
        }
        return 52 -k;
    }

    public boolean isInOrder() {
        return sequenceDistance() == (cards.size() -1);
    }



    public int size() {
        return cards == null ? 0 : cards.size();
    }

    public List<Card> getCards() {
        return Collections.unmodifiableList(this.cards);
    }

    public void remove(Collection<Card> moveTo) {
        cards.removeAll(moveTo);
    }

    public void appendTo(Collection<Card> moveTo) {
        cards.addAll(moveTo);
        moveTo.forEach(c -> c.setCurrentColumn(this));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SolitaireColumn that = (SolitaireColumn) o;
        return Objects.equals(cards, that.cards);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cards, col);
    }

    public Card addCard(Card.Kind kind, char value, Deck deck) {
        Card card = deck.seek(kind, value);
        card.setCurrentColumn(this);
        cards.add(card);
        return card;
    }

    public boolean isEmpty() {
        return cards.isEmpty();
    }

    public List<Card> range(int a, int b) {
        return this.cards.subList(a , b);
    }

    public int getOrder() {
        return this.col;
    }


    public CardRange sequenceFrom(Card c2) {
        CardRange from = c2.getCurrentColumn().from(c2);
        if(from.isSequence() && (this.isEmpty() || this.peek().followedBy(c2)) ) {
            return from;
        }
        return null;
    }

}
