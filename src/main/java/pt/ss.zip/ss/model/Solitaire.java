package pt.felipemarques.ss.model;

import java.util.*;
import java.util.stream.Collectors;

public class Solitaire {
    private List<SolitaireColumn> list = new ArrayList<>();
    private int count = 1;
    private double cost;
    private String movement = "";

    public SolitaireColumn createColumn() {
        SolitaireColumn sc = new SolitaireColumn(count);
        list.add(sc);
        count++;
        return sc;
    }

    public void createColumns(int size) {
        while(size-- > 0) {
            createColumn();
        }
    }

    @Override
    public Solitaire clone() {
        Solitaire clone = new Solitaire();
        for(SolitaireColumn col : this.list) {
            clone.list.add(col.clone());
        }
        return clone;
    }

    public static class Movement {
        private CardRange range;
        private int col;

        protected Movement(){}

        public CardRange getRange() {
            return range;
        }

        public void setRange(CardRange range) {
            this.range = range;
        }

        public int getCol() {
            return col;
        }

        public void setCol(int col) {
            this.col = col;
        }

        @Override
        public String toString() {
            return this.range.peek().simpleDisplay() + ";" + this.col;
        }
    }

    // NAO ESTA BEM
    public List<Movement> successorsMovements(Deck deck) {
        final List<Movement> movements = new ArrayList<>();
        deck.forEachUsedCard( c2 -> {
            for(SolitaireColumn col : list) {
                CardRange sequenceFrom = col.sequenceFrom(c2);
                if(!col.equals(c2.getCurrentColumn()) && sequenceFrom != null) {
                    Movement movement = new Movement();
                    movement.setRange(sequenceFrom);
                    movement.setCol(col.getOrder());
                    movements.add(movement);
                    System.out.println("From "+ c2.getCurrentColumn().getOrder() + ": " +  c2.getCurrentColumn().simpleDisplay() + " move " +  sequenceFrom.simpleDisplay() +  " to " + col.getOrder() + ": " + col.simpleDisplay());
                }
            }
        });

        return movements;
    }

    // NAO ESTA BEM
    public Set<Solitaire> successors(Deck deck) {
        Set<Solitaire> solitaires = new HashSet<>();
        successorsMovements(deck).forEach( mov -> {
            Solitaire clone = this.clone();
            clone.move(mov);
            solitaires.add(clone);
        });
        return solitaires;
        /*Set<Solitaire> solitaires = new HashSet<>();
        for(int i = 0; i < list.size(); i++) {
            for(int j = 0; j < list.size(); j++) {
                if(i!=j &&  !list.get(i).isEmpty()) {
                    Solitaire clone  = this.clone();
                    if(clone.move(i, j) && !clone.equals(this)) {
                        solitaires.add(clone);
                    }

                    for (int k = 0; k < list.size(); k++){
                        clone  = this.clone();
                        if(clone.move(i, j, k)  && !clone.equals(this)) {
                            solitaires.add(clone);
                        }
                    }
                }
            }
        }
        return solitaires;*/
    }

    public void move(Movement movement) {
        final SolitaireColumn solitaireColumn = this.list.get(movement.getCol() - 1);
        movement.getRange().detachFromColumn();
        solitaireColumn.appendTo(movement.range.cards);
    }

    public boolean move(int f, int t) {
        SolitaireColumn columnFrom = list.get(f);
        if(columnFrom.isEmpty())
            return false;

        Card from = columnFrom.peek();

        if(list.get(t).isEmpty()) {
            columnFrom.pop();
            this.movement = "(1) Add " + from.simpleDisplay() + " to column " + t + " <empty> ";
            System.out.println(movement);
            list.get(t).add(from);
            return true;
        }


        Card to =list.get(t).peek();
        if(to.followedBy(from)) {
            from = columnFrom.pop();
            this.movement =  "(2) Add " + from.simpleDisplay() + " to column " + t + " = " + list.get(t).simpleDisplay();
            System.out.println(movement);
            list.get(t).add(from);
            return true;
        }
        return false;
    }

    public boolean move(int f, int t, int deep) {

        SolitaireColumn columnFrom = list.get(f);
        List<Card> deckFrom = columnFrom.getCards();
        boolean consistent = true;
        int i;
        Card first = null;
        for(i = deep; i < deckFrom.size()-1; i++){
            first = deckFrom.get(i);
            Card second = deckFrom.get(i+1);
            if(!second.canLink(first)){
                consistent = false;
                break;
            }

        }

        //System.out.println("Try move from " + f + " to column " + t + " = " + list.get(t).simpleDisplay());

        if(first == null || !consistent)
            return false;

        if(consistent && (list.get(t).isEmpty() || list.get(f).peek().canLink(list.get(t).getCards().get(0)))) {
            List<Card> range = list.get(f).range(deep, list.get(f).size());

            this.movement = "(3) Add " + Card.display(range) + " to column " + t + " = " + list.get(t).simpleDisplay();
            System.out.println(this.movement);

            list.get(t).appendTo(range);
            columnFrom.remove(range);
            return true;
        }

        return false;
    }

    public String simpleDisplay() {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < list.size(); i++) {
            sb.append(i+1);
            sb.append(" = ");
            sb.append(list.get(i).simpleDisplay());
            sb.append("\n");
        }
        return sb.toString();
    }

    public String display() {
        List<String[]> displayList = list.stream().map(sc -> sc.display().split("\r\n")).collect(Collectors.toList());
        String[] longest = displayList.stream().max((c1, c2) -> c1.length - c2.length).orElse(null);
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < longest.length; i++) {

            for(int j = 0; j < list.size(); j++) {
                String [] col = displayList.get(j);
                if(col.length > i) {
                    sb.append(col[i]);
                } else {
                    sb.append("   ░░░░░░   ");
                }
                sb.append("\t");
            }
            sb.append("\r\n");
        }

        return sb.toString();
    }

    // Heurísticas
    public int simpleDistance() {
        return list.stream().map( c -> c.simpleDistance()).reduce((c1, c2) -> c1 + c2).orElse(Integer.MAX_VALUE);
    }

    public int distance() {
        return list.stream().map( c -> c.distance()).reduce((c1, c2) -> c1 + c2).orElse(Integer.MAX_VALUE);
    }

    public int sequenceDistance() {
        return list.stream().map( c -> c.sequenceDistance()).reduce((c1, c2) -> c1 + c2).orElse(Integer.MAX_VALUE);
    }

    public int kindConsistency() {
        return list.stream().map( c -> c.kindConsistency()).reduce((c1, c2) -> c1 + c2).orElse(Integer.MAX_VALUE);
    }

    public boolean isSolved() {
        return this.list.stream().map(c -> c.isSolved()).reduce((c1, c2) -> c1 && c2).orElse(false);
    }

    public boolean isInOrder() {
        return this.list.stream().map(c -> c.isInOrder()).reduce((c1, c2) -> c1 && c2).orElse(false);
    }

    //Grau de liberdade (quantos canMove por carta tem)???

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Solitaire solitaire = (Solitaire) o;
        return Objects.deepEquals(list, solitaire.list);
    }

    @Override
    public int hashCode() {
        return Objects.hash(list);
    }

    public SolitaireColumn column(int i) {
        return list.get(i);
    }

    public String getMovement() {
        return movement;
    }
}
