package pt.felipemarques.ss.model;

import java.util.*;

public final class Card implements Comparable<Card> {

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";

    private final Kind kind;
    private final char value;
    private static Map<String,Card> cards = new HashMap<>();
    private SolitaireColumn currentColumn;

    static {
        getCard(Kind.clubs, 'A');
        getCard(Kind.clubs, '2');
        getCard(Kind.clubs, '3');
        getCard(Kind.clubs, '4');
        getCard(Kind.clubs, '5');
        getCard(Kind.clubs, '6');
        getCard(Kind.clubs, '7');
        getCard(Kind.clubs, '8');
        getCard(Kind.clubs, '9');
        getCard(Kind.clubs, '0');
        getCard(Kind.clubs, 'V');
        getCard(Kind.clubs, 'D');
        getCard(Kind.clubs, 'R');

        getCard(Kind.hearts, 'A');
        getCard(Kind.hearts, '2');
        getCard(Kind.hearts, '3');
        getCard(Kind.hearts, '4');
        getCard(Kind.hearts, '5');
        getCard(Kind.hearts, '6');
        getCard(Kind.hearts, '7');
        getCard(Kind.hearts, '8');
        getCard(Kind.hearts, '9');
        getCard(Kind.hearts, '0');
        getCard(Kind.hearts, 'V');
        getCard(Kind.hearts, 'D');
        getCard(Kind.hearts, 'R');

        getCard(Kind.diamonds, 'A');
        getCard(Kind.diamonds, '2');
        getCard(Kind.diamonds, '3');
        getCard(Kind.diamonds, '4');
        getCard(Kind.diamonds, '5');
        getCard(Kind.diamonds, '6');
        getCard(Kind.diamonds, '7');
        getCard(Kind.diamonds, '8');
        getCard(Kind.diamonds, '9');
        getCard(Kind.diamonds, '0');
        getCard(Kind.diamonds, 'V');
        getCard(Kind.diamonds, 'D');
        getCard(Kind.diamonds, 'R');

        getCard(Kind.spades, 'A');
        getCard(Kind.spades, '2');
        getCard(Kind.spades, '3');
        getCard(Kind.spades, '4');
        getCard(Kind.spades, '5');
        getCard(Kind.spades, '6');
        getCard(Kind.spades, '7');
        getCard(Kind.spades, '8');
        getCard(Kind.spades, '9');
        getCard(Kind.spades, '0');
        getCard(Kind.spades, 'V');
        getCard(Kind.spades, 'D');
        getCard(Kind.spades, 'R');
    }

    private Card(Kind kind, char value) {
        this.kind = kind;
        this.value = value;
    }

    public static Card getCard(Kind kind, char value) {
        if(!cards.containsKey(kind.name() + "" + value)) {
            cards.put(kind.name() + "" + value, new Card(kind, value));
        }
        return cards.get(kind.name() + "" + value);
    }

    public static List<Card> getAllCards() {
        return new ArrayList<>(cards.values());
    }

    public static String display(List<Card> range) {
        StringBuilder sb = new StringBuilder();
        for(Card c : range)
            sb.append(c.simpleDisplay() + " ");

        return sb.toString();
    }

    public Kind getKind() {
        return kind;
    }

    public char getValue() {
        return value;
    }


    public String display(int spaces) {
        return  getSpaces(spaces) + "┌────┐"+getSpaces(spaces)+"\r\n" +
                getSpaces(spaces) + "│" + kind.toString() + (value == '0' ? "1" : "") + value + (value == '0' ? " " : "  ") + "│"+getSpaces(spaces)+"\r\n" +
                getSpaces(spaces) + "│    │"+getSpaces(spaces)+"\r\n" +
                getSpaces(spaces) + "└────┘"+getSpaces(spaces)+"\r\n";

    }

    public static String emptyCard(int spaces) {
        return  getSpaces(spaces) + "┌────┐"+getSpaces(spaces)+"\r\n" +
                getSpaces(spaces) + "│" + " " + ("") + " " + ("  ") + "│"+getSpaces(spaces)+"\r\n" +
                getSpaces(spaces) + "│    │"+getSpaces(spaces)+"\r\n" +
                getSpaces(spaces) + "└────┘"+getSpaces(spaces)+"\r\n";

    }

    private static String getSpaces(int spaces) {
        String s = "";
        for(int i = 0; i < spaces; i++) {
            s += " ";
        }
        return s;
    }

    public boolean greatherThan(Card c) {
        return getIntVal(this.value) > getIntVal(c.value);
    }



    public String simpleDisplay() {
        return kind.color + (value == '0' ? "10" : value) +  getSimpleKind() + ANSI_RESET;
    }

    private String getSimpleKind() {
        switch (kind) {
            case clubs:
                return "P";
            case diamonds:
                return "O";
            case hearts:
                return "C";
            case spades:
                return "E";
        }
        return null;
    }

    public boolean followedBy(Card second) {
        return getIntVal(this.value) == (getIntVal(second.value))+1;
    }

    @Override
    public int compareTo(Card o) {
        return Integer.valueOf(getIntVal(this.value)).compareTo(getIntVal(o.value));
    }

    public boolean canLink(Card other) {
        return other.getKind().equals(this.getKind()) && other.followedBy(this);
    }


    public enum Kind {
        clubs ("♣", ANSI_BLACK), diamonds ("♦", ANSI_RED), hearts ("♥", ANSI_RED), spades ("♠", ANSI_BLACK);
        private final String symbol, color;

        Kind(String symbol, String color) {
            this.symbol = symbol;
            this.color = color;
        }

        @Override
        public String toString() {
            return color + symbol + color + ANSI_RESET;
        }
    }

    private static int getIntVal(char value) {
        switch (value) {
            case 'A': return 1;
            case '2': return 2;
            case '3': return 3;
            case '4': return 4;
            case '5': return 5;
            case '6': return 6;
            case '7': return 7;
            case '8': return 8;
            case '9': return 9;
            case '0': return 10;
            case 'V': return 11;
            case 'D': return 12;
            case 'R': return 13;
            default:
                throw new RuntimeException("Invalid card value: " + value);
        }
    }

    public static Map<String, Card> getCards() {
        return cards;
    }

    public static void setCards(Map<String, Card> cards) {
        Card.cards = cards;
    }

    public SolitaireColumn getCurrentColumn() {
        return currentColumn;
    }

    public void setCurrentColumn(SolitaireColumn currentColumn) {
        this.currentColumn = currentColumn;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Card card = (Card) o;
        return value == card.value && kind == card.kind;
    }

    @Override
    public int hashCode() {
        return Objects.hash(kind, value);
    }
}
