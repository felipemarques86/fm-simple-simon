package pt.felipemarques.ss.model;

import java.util.Stack;

public class CardRange {
    protected Stack<Card> cards = new Stack<>();

    protected void add(Card c) {
        cards.push(c);
    }

    public boolean isSequence() {
        for(int i = 0; i < cards.size()-1; i++) {
            Card card1 = cards.get(i);
            Card card2 = cards.get(i+1);
            if(!card1.followedBy(card2) || !card1.getKind().equals(card2.getKind())) {
                return false;
            }
        }
        return true;
    }

    public CardRange from(Card card) {
        boolean add = false;
        CardRange range = new CardRange();
        for(Card c : cards) {
            if (c.equals(card)) {
                add = true;
            }
            if(add) {
                range.add(c);
            }
        }
        return range;
    }

    public Card peek() {
        return cards.peek();
    }

    public void detachFromColumn() {
        this.cards.get(0).getCurrentColumn().remove(this.cards);
    }

    public String simpleDisplay() {
        StringBuilder sb = new StringBuilder();
        for(Card card : cards) {
            sb.append(card == null ? "N" : card.simpleDisplay());
            sb.append(" ");
        }
        return sb.toString();
    }
}
