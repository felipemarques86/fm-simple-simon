package pt.felipemarques.ss.search;

import pt.felipemarques.ss.model.Deck;
import pt.felipemarques.ss.model.Solitaire;

import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;

public class AStarSearch implements Search {
    private Solitaire solution;
    private int expansions, iterations;

    @Override
    public Solitaire search(Solitaire initialSolution, Deck deck) {
        long t0 = System.currentTimeMillis();
        Set<Solitaire> closedList = new HashSet<>();
        PriorityQueue<Solitaire> openList = new PriorityQueue<>(20, (o1, o2) -> {
            if((o1.distance() +o1.sequenceDistance() + o1.kindConsistency()) < (o2.distance() +o2.sequenceDistance() + o2.kindConsistency())) {
                return 1;
            } else if((o1.distance() +o1.sequenceDistance() + o1.kindConsistency()) > (o2.distance() +o2.sequenceDistance() + o2.kindConsistency())) {
                return -1;
            }
            return 0;
        });

        initialSolution.setCost(0);
        openList.add(initialSolution);

        System.out.println(initialSolution.display());

        while(!openList.isEmpty()) {
            increaseIterations();

            Solitaire current = openList.poll();
            closedList.add(current);

            if(current.isSolved()) {
                return current;
            }

            if(iterations == 300)
                return current;

            Set<Solitaire> successors = current.successors(deck);
            increaseExpansions(successors.size());
            for(Solitaire solitaire : successors) {

                if(!openList.contains(solitaire) && !closedList.contains(solitaire)) {
                    solitaire.setCost(current.getCost()+1);
                    openList.add(solitaire);
                } else {
                    double f = solitaire.sequenceDistance() + solitaire.kindConsistency() + solitaire.distance() + current.getCost() + 1;
                    double f2 = current.sequenceDistance() + current.kindConsistency() + current.distance() + current.getCost();
                    if(f < f2 && closedList.contains(solitaire)) {
                        solitaire.setCost(current.getCost() + 1);
                        closedList.remove(solitaire);
                        openList.add(solitaire);
                    }
                }
            }

            /*if( System.currentTimeMillis()-t0 > 1000) {
                System.out.println("Solução não encontrada");
                return solution = current;
            }*/
        }

        return solution;
    }

    @Override
    public Solitaire getSolution() {
        return solution;
    }

    @Override
    public void increaseExpansions(int amount) {
        expansions+=amount;
    }

    @Override
    public int getExpansions() {
        return expansions;
    }

    @Override
    public void increaseIterations() {
        iterations++;
    }

    @Override
    public int getIterations() {
        return iterations;
    }

}
