package pt.felipemarques.ss.search;

import pt.felipemarques.ss.model.Deck;
import pt.felipemarques.ss.model.Solitaire;

public interface Search {

    Solitaire search(Solitaire initialSolution, Deck deck);
    Solitaire getSolution();
    void increaseExpansions(int amount);
    int getExpansions();
    void increaseIterations();
    int getIterations();


}
