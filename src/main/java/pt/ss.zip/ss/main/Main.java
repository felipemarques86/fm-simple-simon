package pt.felipemarques.ss.main;

import pt.felipemarques.ss.model.Card;
import pt.felipemarques.ss.model.Deck;
import pt.felipemarques.ss.model.Solitaire;
import pt.felipemarques.ss.model.SolitaireColumn;

import java.util.Collection;

import static pt.felipemarques.ss.model.Card.ANSI_GREEN;
import static pt.felipemarques.ss.model.Card.ANSI_RESET;


public class Main {

    public static void main(String ... args) {
        Deck deck = new Deck();
        deck.shuffle();

        Solitaire solitaire = new Solitaire();
        SolitaireColumn col1 = solitaire.createColumn();
        col1.add(deck.seek(Card.Kind.hearts, '0'));
        col1.add(deck.seek(Card.Kind.spades, '4'));
        col1.add(deck.seek(Card.Kind.hearts, '2'));
        col1.add(deck.seek(Card.Kind.hearts, '8'));
        col1.add(deck.seek(Card.Kind.diamonds, '8'));
        col1.add(deck.seek(Card.Kind.clubs, '0'));

        SolitaireColumn col2 = solitaire.createColumn();
        col2.add(deck.seek(Card.Kind.diamonds, 'V'));
        col2.add(deck.seek(Card.Kind.diamonds, '3'));
        col2.add(deck.seek(Card.Kind.diamonds, '7'));

        SolitaireColumn col3 = solitaire.createColumn();
        col3.add(deck.seek(Card.Kind.spades, '9'));
        col3.add(deck.seek(Card.Kind.spades, 'A'));
        col3.add(deck.seek(Card.Kind.diamonds, 'A'));
        col3.add(deck.seek(Card.Kind.spades, '5'));
        col3.add(deck.seek(Card.Kind.hearts, '4'));
        col3.add(deck.seek(Card.Kind.diamonds, 'D'));
        col3.add(deck.seek(Card.Kind.hearts, 'R'));

        SolitaireColumn col4 = solitaire.createColumn();
        col4.add(deck.seek(Card.Kind.clubs, '4'));
        col4.add(deck.seek(Card.Kind.clubs, 'V'));
        col4.add(deck.seek(Card.Kind.hearts, '5'));
        col4.add(deck.seek(Card.Kind.hearts, '9'));
        col4.add(deck.seek(Card.Kind.clubs, '8'));
        col4.add(deck.seek(Card.Kind.hearts, 'V'));

        /*  6E
            3E
            AC
            4O
            8E
            10E
            10O
         */

        SolitaireColumn col5 = solitaire.createColumn();
        col5.add(deck.seek(Card.Kind.spades, '6'));
        col5.add(deck.seek(Card.Kind.spades, '3'));
        col5.add(deck.seek(Card.Kind.hearts, 'A'));
        col5.add(deck.seek(Card.Kind.diamonds, '4'));
        col5.add(deck.seek(Card.Kind.spades, '8'));
        col5.add(deck.seek(Card.Kind.spades, '0'));
        col5.add(deck.seek(Card.Kind.diamonds, '0'));

        /*
            2O
            6C
            AP
            2E
            3C
            6O
         */

        SolitaireColumn col6 = solitaire.createColumn();
        col6.add(deck.seek(Card.Kind.diamonds, '2'));
        col6.add(deck.seek(Card.Kind.hearts, '6'));
        col6.add(deck.seek(Card.Kind.clubs, 'A'));
        col6.add(deck.seek(Card.Kind.spades, '2'));
        col6.add(deck.seek(Card.Kind.hearts, '3'));
        col6.add(deck.seek(Card.Kind.diamonds, '6'));

        /*
            DP
            7E
            DC
            2P
            7C
            RO
            RP
            DE
         */

        SolitaireColumn col7 = solitaire.createColumn();
        col7.add(deck.seek(Card.Kind.clubs, 'D'));
        col7.add(deck.seek(Card.Kind.spades, '7'));
        col7.add(deck.seek(Card.Kind.hearts, 'D'));
        col7.add(deck.seek(Card.Kind.clubs, '2'));
        col7.add(deck.seek(Card.Kind.hearts, '7'));
        col7.add(deck.seek(Card.Kind.diamonds, 'R'));
        col7.add(deck.seek(Card.Kind.clubs, 'R'));
        col7.add(deck.seek(Card.Kind.spades, 'D'));

        /*
            5P
            5O
         */

        SolitaireColumn col8 = solitaire.createColumn();
        col8.add(deck.seek(Card.Kind.clubs, '5'));
        col8.add(deck.seek(Card.Kind.diamonds, '5'));

        /*
            3P
            9P
            RE
            6P
         */

        SolitaireColumn col9 = solitaire.createColumn();
        col9.add(deck.seek(Card.Kind.clubs, '3'));
        col9.add(deck.seek(Card.Kind.clubs, '9'));
        col9.add(deck.seek(Card.Kind.spades, 'R'));
        col9.add(deck.seek(Card.Kind.clubs, '6'));

        /*
            7P
            9O
            VE
         */

        SolitaireColumn col10 = solitaire.createColumn();
        col10.add(deck.seek(Card.Kind.clubs, '7'));
        col10.add(deck.seek(Card.Kind.diamonds, '9'));
        col10.add(deck.seek(Card.Kind.spades, 'V'));


        /*System.out.println(solitaire.display());

        solitaire.move(Card.Kind.clubs, '0', 4);

        System.out.println(solitaire.display());*/


        Collection<Solitaire> successors = solitaire.successors(deck);

        boolean simpleDisplay = true;

        if(simpleDisplay) {
            for(Solitaire sol : successors) {
                System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
                System.out.println(sol.simpleDisplay());
                System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
            }
        } else {

            for (Solitaire sol : successors) {
                System.out.println("─────────────────────────────────────────────────────────────────────────── " + ANSI_GREEN + sol.sequenceDistance() + ANSI_GREEN + ANSI_RESET + " ────────────────────────────────────────────────────────────────────────────");
                System.out.println("Simple Distance: " + sol.simpleDistance());
                System.out.println("Distance: " + sol.distance());
                System.out.println("Sequence Distance: " + sol.sequenceDistance());
                System.out.println("Kind Consistency: " + sol.kindConsistency());
                System.out.println("Solved? " + sol.isSolved());
                System.out.println("In order? " + sol.isInOrder());
                System.out.println();
                System.out.println(sol.simpleDisplay());
                System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
                System.out.println();
            }
        }

        System.out.println("Sucessores: " + successors.size());

    }
}
